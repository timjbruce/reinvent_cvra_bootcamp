import vehicleSdk from 'n526-vehicle-sdk'
import AuthService from './AuthService'

/**
* Credential provider constructor.
*/

export default class VehicleApiService {
  static AWS_REGION = 'us-east-1';

  constructor () {
    this.auth = AuthService.getInstance()
    this.client = vehicleSdk.newClient(this.auth.getCredentials())
  }

  signRequest () {
    console.log('INFO: Signing request')
    console.log('INFO: Credentials: ' + this.credentials)
  }

  getTrips (vin) {
    console.log('INFO: Getting list of trips')
    return new Promise((resolve, reject) => {
      this.client.vehiclesVinTripsGet({ vin })
        .then(data => resolve(data.data.data.Items))
        .catch(err => reject(err))
    })
  }

  getTrip (trip_id, vin) {
    console.log('INFO: Getting trip details')
    return new Promise((resolve, reject) => {
      console.log(`Querying trip ${trip_id} and vin ${vin}`)
      this.client.vehiclesVinTripsTripIdGet({ trip_id, vin })
        .then(data => resolve(data.data.trip_info.Item))
        .catch(err => reject(err))
    })
  }

  static getInstance () {
    if (!VehicleApiService._instance) VehicleApiService._instance = new VehicleApiService()
    return VehicleApiService._instance
  }
}
