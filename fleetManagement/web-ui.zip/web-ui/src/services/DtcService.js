import async from 'async'
import aws from 'aws-sdk'
import deviceSdk from 'aws-iot-device-sdk'
import AuthService from './AuthService'
import ConfigurationService from './ConfigurationService'
//import commandSdk from 'n526-command-sdk'

export default class DtcService {
  constructor () {
    this.auth = AuthService.getInstance()
    this.config = ConfigurationService.getInstance()

    // FIXME Move this to config
    // FIXME for prod the values are different
    this.dtcMasterTableName = 'CVRA-PoC-DevCICD-DtcTable-WI2H8QHRMHWL'
    this.dtcTableName = 'CVRA-PoC-DevCICD-VehicleDtcTable-1HGNF44IO7K61'
    this.auditTable = 'n526VehicleCommandAuditTable'

    const credentials = this.auth.getCredentials()
    this.dynamo = new aws.DynamoDB.DocumentClient({
      region: this.config.get('AWS_REGION'),
      credentials
    })

    this.commandSdk = commandSdk.newClient(credentials)
  }

  clearDtc (vin, dtc_id) {
    const user_uuid = this.auth.sub

    const params = {
      cmd: 14,
      vin,
      args: [dtc_id],
      timestamp: new Date().getTime(),
      user_uuid
    }

    return new Promise((resolve, reject) => {
      this.commandSdk.vehiclesVinCommandsPost({ vin }, params)
        .then(data => resolve(data))
        .catch(err => reject(err))
    })
  }

  getDtcInfo () {
    const TableName = this.dtcMasterTableName

    const params = {
      TableName
    }

    return new Promise((resolve, reject) => {
      this.dynamo.scan(params, (err, data) => {
        if (err) {
          console.error(`ERROR: Failed to fetch DTC master information`)
          reject(err)
        } else {
          resolve(data.Items)
        }
      })
    })
  }

  getAllDtcs () {
    const TableName = this.dtcTableName

    const params = {
      TableName
    }

    return new Promise((resolve, reject) => {
      async.waterfall([
        cb => {
          this.getDtcInfo()
            .then(data => cb(null, data))
            .catch(err => cb(err))
        },
        (master, cb) => {
          this.dynamo.scan(params, (err, data) => {
            if (err) {
              console.error(`ERROR: Failed to fetch DTC codes for vin ${vin}`)
              reject(err)
            } else {
              const items = data.Items.filter(item => !item.acknowledged)
                .map(item => {
                  const ret = { ...item }
                  const masterInfo = master.filter(info => info.dtc === ret.dtc)[0]
                  if (!masterInfo) {
                    // TODO Throw exception
                  }

                  ret.master = masterInfo
                  ret.count = 1

                  return ret
                })

              const uniqueItems = []
              for (let i = 0; i < items.length; i++) {
                const currentItem = items[i]
                const existingItem = uniqueItems.filter(item => item.dtc === currentItem.dtc)[0]
                if (existingItem) {
                  existingItem.count++
                } else {
                  uniqueItems.push(currentItem)
                }
              }
              resolve(uniqueItems)
            }
          })
        }
      ], (err, data) => {
        if (err) {
          console.error('ERROR: Failed to fetch aggregated DTC codes.')
          reject(err)
        } else {
          resolve(data)
        }
      })
    })
  }

  getDtcCodes (vin) {
    return new Promise((resolve, reject) => {
      async.waterfall([
        cb => {
          this.getDtcInfo()
            .then(data => cb(null, data))
            .catch(err => cb(err))
        },
        (master, cb) => {
          const TableName = this.dtcTableName
          const KeyConditionExpression = 'vin = :vin'
          const ExpressionAttributeValues = {
            ':vin': vin
          }

          const params = {
            TableName,
            KeyConditionExpression,
            ExpressionAttributeValues
          }

          this.dynamo.query(params, (err, data) => {
            if (err) {
              console.error(`ERROR: Failed to fetch DTC codes for vin ${vin}`)
              reject(err)
            } else {
              const items = data.Items.filter(item => !item.acknowledged)
                .map(item => {
                  const ret = { ...item }
                  const masterInfo = master.filter(info => info.dtc === ret.dtc)[0]
                  if (!masterInfo) {
                    // TODO Throw exception
                  }

                  ret.master = masterInfo
                  ret.count = 1

                  return ret
                })

              const uniqueItems = []
              for (let i = 0; i < items.length; i++) {
                const currentItem = items[i]
                const existingItem = uniqueItems.filter(item => item.dtc === currentItem.dtc)[0]
                if (existingItem) {
                  existingItem.count++
                } else {
                  uniqueItems.push(currentItem)
                }
              }
              resolve(uniqueItems)
            }
          })
        }
      ], (err, data) => {
        if (err) {
          console.error('ERROR: Failed to fetch aggregated DTC codes.')
          reject(err)
        } else {
          resolve(data)
        }
      })
    })
  }

  static getInstance () {
    if (!DtcService._instance) DtcService._instance = new DtcService()
    return DtcService._instance
  }
}
