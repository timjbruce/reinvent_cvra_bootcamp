<template>
  <div class="view cover service-admins">
    <!-- Customer search -->
    <customer-search v-if="$route.params.section === 'customer-search'" v-on:customerSelection="selectCustomer($event)"></customer-search>

    <!-- Vehicle overview -->
    <vehicle-overview :fields="vehicleFields" :vehicle="vehicle" :owner="owner" v-if="$route.params.section === 'vehicle-overview'"></vehicle-overview>
  </div>
</template>

<script>
import CustomerSearch from '@/components/sections/CustomerSearch'
import VehicleOverview from '@/components/sections/VehicleOverview'
import OwnerService from '@/services/OwnerService'
import VehicleService from '@/services/VehicleService'

export default {
  name: 'serviceAdminView',
  components: {
    CustomerSearch,
    VehicleOverview
  },
  created () {
    this.ownerService = OwnerService.getInstance()
    this.vehicleService = VehicleService.getInstance()
  },
  data () {
    return {
      owner: {},
      vehicle: {},
      vehicleFields: [
        'vehicle_owner',
        'vehicle_registration'
      ]
    }
  },
  methods: {
    fetchData () {
      if (this.$route.params.subsection) {
        const vin = this.$route.params.subsection
        this.vehicleService.getVehicleInformation(vin, true)
          .then(data => {
            this.vehicle = data
            this.ownerService.getUserByUuid(data.owner)
              .then(data => {
                this.owner = data
              })
              .catch(err => {
                console.error(err)
              })
          })
          .catch(err => {
            console.error(err)
          })
      }
    },
    selectCustomer (payload) {
      const ownerRef = payload.owner
      const ownerSub = ownerRef.Attributes.filter(item => item.Name === 'sub')[0].Value
      this.vehicleService.listOwnedVehicles(ownerSub)
        .then(data => {
          this.$router.push(`/service-admins/vehicle-overview/${data.vin}`)
        })
        .catch(err => {
          console.error(err)
        })
    }
  },
  watch: {
    $route (val) {
      this.fetchData()
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
.view.service-admins {
  width: 100%;
  height: 100%;
  display: block;
}

</style>
