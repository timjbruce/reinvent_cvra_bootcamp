<template>
  <div class="badge badge-block badge-padded" :class="this.iotStatus | statusClass">
    {{ friendlyConnectionStatus }}
      <span class="connection-time">{{ FormatTimeString(statusLastUpdated, this.iotStatus) }}</span>
  </div>
</template>

<script>
export default {
  name: 'connectionStatus',
  props: ['iotStatus', 'statusLastUpdated'],
  computed: {
    friendlyConnectionStatus () {
      switch (this.iotStatus) {
        case 'online':
        case 'sleep':
          return 'Connected.'
        case 'deep-sleep':
          return 'Waking up car...'
        case 'critical-sleep':
          return 'Car has shut down due to low battery.'
        case 'connecting':
          return 'Connecting to the car...'
        case 'connection-lost':
          return 'Cannot connect to car.'
        default:
          return this.iotStatus
      }
    }
  },
  data () {
    return {
    }
  },
  filters: {
    statusClass (value) {
      switch (value) {
        case 'online':
        case 'sleep':
          return 'badge-success'
        case 'deep-sleep':
        case 'connecting':
          return 'badge-warning'
        case 'critical-sleep':
          return 'badge-danger'
        case 'connection-lost':
          return 'badge-danger'
        default:
          return 'badge-danger' //we don't recognise the status
      }
    }
  },
  methods: {
    //convert unix timestamp to formatted string for display
    FormatTimeString (UnixTimestamp, connectionStatus) {
      if (!UnixTimestamp) {
        return 'never seen'
      }
      var a = new Date(UnixTimestamp * 1000)
      var elapsed = Date.now() - a

      var msPerMinute = 60 * 1000
      var msPerHour = msPerMinute * 60
      var msPerDay = msPerHour * 24
      var msPerMonth = msPerDay * 30
      var msPerYear = msPerDay * 365

      if (connectionStatus === 'online') {
        //we don't show the time if it is currently connected
        return ''
      } else {
        if (elapsed < 2 * msPerMinute) {
          return 'Last updated ' + Math.round(elapsed / 1000) + ' seconds ago.'
        } else if (elapsed < 2 * msPerHour) {
          return 'Last updated ' + Math.round(elapsed / msPerMinute) + ' minutes ago.'
        } else if (elapsed < 2 * msPerDay) {
          return 'Last updated ' + Math.round(elapsed / msPerHour) + ' hours ago.'
        } else if (elapsed < 2 * msPerMonth) {
          return 'Last updated  ' + Math.round(elapsed / msPerDay) + ' days ago.'
        } else if (elapsed < 2 * msPerYear) {
          return 'Last updated  ' + Math.round(elapsed / msPerMonth) + ' months ago.'
        } else {
          return 'Last updated  ' + Math.round(elapsed / msPerYear) + ' years ago.'
        }
      }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
@import '../../assets/colors.scss';
@import '../../assets/sizes.scss';

.section.vehicle-overview {
  .vehicle-info {
    .connection-status {
      text-transform: capitalize;
    }
  }
}

</style>
