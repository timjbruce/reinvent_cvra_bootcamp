<template>
  <div class="fault-list">
    <div class="list lg">
      <div class="list-header">
        <div class="col col-sixth">DTC</div>
        <div class="col col-sixth">System</div>
        <div class="col col-third">Description</div>
        <div class="col col-sixth">Count</div>
        <div class="col col-sixth">Clear DTC</div>
      </div>

      <div class="list-item item-no-hover lg transparent no-hz-padding" v-for="fault in filteredFaultList">
        <div class="col col-sixth">{{ fault.dtc }}</div>
        <div class="col col-sixth text-cap">{{ fault.master.ui_categorisation }}</div>
        <div class="col col-third">{{ fault.description }}</div>
        <div class="col col-sixth">{{ fault.count }}</div>
        <div class="col col-sixth">
          <button
            class="btn"
            :class="{ 'btn-primary': !fault.acknowledged && !fault.$acknowledging, 'btn-default': !fault.acknowledged && fault.$acknowledging, 'btn-success': !fault.$acknowledging && fault.acknowledged }"
            v-on:click="clearDtc(fault)">
            <span v-if="!fault.acknowledged && !fault.$acknowledging">
              Clear DTC
            </span>

            <span v-if="fault.$acknowledging">
              Clearing
              <i class="fa fa-circle-o-notch fa-spin"></i>
            </span>

            <span v-if="fault.acknowledged">
              Cleared
              <i class="fa fa-check-circle"></i>
            </span>
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import DtcService from '@/services/DtcService'

export default {
  name: 'faultList',
  props: ['faults', 'filter', 'pending'],
  created () {
    this.dtcService = DtcService.getInstance()
    this.fetchFaultMasterData()
    this.parseData()
  },
  data () {
    return {
      allFaults: this.faults || [],
      faultMasterData: [],
      filteredFaultList: []
    }
  },
  mounted () {
    this.parseData()
  },
  methods: {
    clearDtc (fault) {
      const vin = fault.vin
      const id = fault.dtc_id

      fault.$acknowledging = true
      this.dtcService.clearDtc(vin, id)
        .then(data => {
          fault.exe_id = data.data.exe_id
          this.pending.push(fault)
        })
        .catch(err => {
          console.error(err)
        })

      this.$forceUpdate()
    },
    fetchFaultMasterData () {
      this.dtcService.getDtcInfo()
        .then(data => {
          this.faultMasterData = data
        })
        .catch(err => {
          console.error(err)
        })
    },

    getCurrentDtc (code) {
      return this.faultMasterData.filter(item => item.dtc === code)[0] || {}
    },

    parseData () {
      console.log('parsing')
      this.filteredFaultList = this.filter ? this.allFaults.filter(item => item.master.ui_categorisation === this.filter) : this.allFaults
    }
  },

  watch: {
    faults () {
      this.parseData()
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
.fault-list {
  margin: 0 30px;

  button {
    width: 125px;
  }
}

</style>
