<template>
  <div class="tyre-pressure">
    <div class="vehicle-container">
      <div class="recommended-pressure rear">
        {{ tyres.RL[1] }} Bar
      </div>
      <div class="recommended-pressure front">
        {{ tyres.FL[1] }} Bar
      </div>
      <div class="wheel front left" :data-pressure="tyres.FL[0]" :class="{ R: tyres.FL[2] == 1, A: tyres.FL[2] == 2, G: tyres.FL[2] == 3 }"></div>
      <div class="wheel front right" :data-pressure="tyres.FR[0]" :class="{ R: tyres.FR[2] == 1, A: tyres.FR[2] == 2, G: tyres.FR[2] == 3 }"></div>
      <div class="wheel rear left" :data-pressure="tyres.RL[0]" :class="{ R: tyres.RL[2] == 1, A: tyres.RL[2] == 2, G: tyres.RL[2] == 3 }"></div>
      <div class="wheel rear right" :data-pressure="tyres.RR[0]" :class="{ R: tyres.RR[2] == 1, A: tyres.RR[2] == 2, G: tyres.RR[2] == 3 }"></div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'tyrePressure',
  props: ['tyres'],
  data () {
    return {
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
@import '../../assets/colors.scss';

.tyre-pressure {
  width: 100%;
  height: 100%;
  display: block;

  .vehicle-container {
    position: relative;
    width: 80%;
    margin: 10em auto;
    max-width: 400px;
    min-height: 200px;
    background: url('../../assets/vehicle@3x.png') center center no-repeat;
    background-size: auto 100%;
    transform: rotate(-90deg);

    .recommended-pressure {
      position: absolute;
      top: 50%;
      margin-top: -1em;
      text-align: center;
      color: $tyre-pressure-recommended-text-color;
      transform: rotate(90deg);
      white-space: nowrap;

      &::after {
        content: 'recommended';
      }

      &.front {
        left: 100%;
        margin-left: -4em;
      }

      &.rear {
        right: 100%;
        margin-right: -4em;
      }
    }

    .wheel {
      position: absolute;
      width: 50px;
      height: 16px;
      border-radius: 3px;

      &::before {
        position: absolute;
        left: 0px;
        width: 100%;
        text-align: center;
        font-size: 2em;
        content: attr(data-pressure);
      }

      &.front {
        right: 20%;
      }

      &.rear {
        left: 20%;
      }

      &.left {
        top: 10%;

        &::before {
          top: -2em;
          transform: rotate(90deg);
        }
      }

      &.right {
        bottom: 10%;

        &::before {
          bottom: -2em;
          transform: rotate(90deg);
        }
      }

      &.R {
        background: url('../../assets/tyres_red.png') center center no-repeat;
        background-size: 100% auto;
      }

      &.A {
        background: url('../../assets/tyres_yellow.png') center center no-repeat;
        background-size: 100% auto;
      }

      &.G {
        background: url('../../assets/tyres_green.png') center center no-repeat;
        background-size: 100% auto;
      }
    }
  }
}

</style>
