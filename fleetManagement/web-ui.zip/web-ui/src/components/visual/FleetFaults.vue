<template>
  <div class="fault-list">
    <div class="list lg">
      <div class="list-header">
        <div class="col col-sixth">DTC</div>
        <div class="col col-sixth">System</div>
        <div class="col col-third">Description</div>
        <div class="col col-sixth">Vehicles affected</div>
        <div class="col col-sixth">&nbsp;</div>
      </div>

      <div class="list-item item-no-hover lg transparent no-hz-padding" v-for="fault in filteredFaultList">
        <div class="col col-sixth">{{ fault.dtc }}</div>
        <div class="col col-sixth text-cap">{{ fault.master.ui_categorisation }}</div>
        <div class="col col-third">{{ fault.description }}</div>
        <div class="col col-sixth">{{ fault.count }}</div>
        <div class="col col-sixth">
          <button
            class="btn btn-link"
            v-on:click="viewDtc (fault)">
            <span>
              View
            </span>
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import DtcService from '@/services/DtcService'

export default {
  name: 'fleetFaults',
  props: ['faults', 'filter', 'pending'],
  created () {
    this.dtcService = DtcService.getInstance()
    this.fetchFaultMasterData()
    this.parseData()
  },
  data () {
    return {
      faultList: this.faults || [],
      faultMasterData: [],
      filteredFaultList: []
    }
  },
  mounted () {
    this.parseData()
  },
  methods: {
    viewDtc (fault) {
      const vin = fault.vin
      const id = fault.dtc_id

      this.$router.push(`/fleet-admins/vehicle-overview/${vin}`)
    },
    fetchFaultMasterData () {
      this.dtcService.getDtcInfo()
        .then(data => {
          this.faultMasterData = data
        })
        .catch(err => {
          console.error(err)
        })
    },

    getCurrentDtc (code) {
      return this.faultMasterData.filter(item => item.dtc === code)[0] || {}
    },

    parseData () {
      this.filteredFaultList = this.filter ? this.faults.filter(item => item.master.ui_categorisation === this.filter) : this.faults
    }
  },
  watch: {
    faults () {
      this.parseData()
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
.fault-list {
  margin-top: 2em;

  button {
    font-size: 1em;

    &::after {
      position: absolute;
      width: 20px;
      height: 20px;
      margin-top: 1px;
      margin-left: 1em;
      background: url('../../assets/right_arrow.svg') center center no-repeat;
      transition: transform 0.3s ease-in-out;
      content: ' ';
    }
  }
}

</style>
