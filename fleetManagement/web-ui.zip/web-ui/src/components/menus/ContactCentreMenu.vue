<template>
  <div class="collapse navbar-collapse menu contact-centre" id="mainMenu">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item menu-item" v-for="item in menuItems" :class="{ active: item.path === $route.params.section }">
        <router-link class="nav-link" :to="`/contact-centre/${item.path}`">
          {{ item.name }}
        </router-link>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'serviceAdminMenu',
  data () {
    return {
      menuItems: [
        {
          path: 'all-tickets',
          name: 'All tickets'
        },
        {
          path: 'customer-search',
          name: 'Find a customer'
        }
      ]
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
.menu.contact-centre {
  width: 100%;
  height: 100%;
  display: block;
}

</style>
