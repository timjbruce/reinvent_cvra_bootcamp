<template>
  <div class="collapse navbar-collapse menu service-admin" id="mainMenu">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item menu-item" v-for="item in menuItems" :class="{ active: item.path === $route.params.section }">
        <router-link class="nav-link" :to="`/service-admins/${item.path}`">
          {{ item.name }}
        </router-link>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'serviceAdminMenu',
  data () {
    return {
      menuItems: [
        {
          path: 'customer-search',
          name: 'Find a customer'
        }
      ]
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
.menu.service-admin {
  width: 100%;
  height: 100%;
  display: block;
}

</style>
