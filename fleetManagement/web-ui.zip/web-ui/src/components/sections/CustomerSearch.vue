<template>
  <div class="section customer-search">
    <div class="panel central">
      <h1 class="title">Find a customer</h1>
      <div class="form vehicle-provisioning">
        <auto-complete label="Customer name" :on-type="findOwners" :on-select="selectOwner"></auto-complete>
      </div>
    </div>
  </div>
</template>

<script>
import AutoComplete from '@/components/visual/AutoComplete'
import OwnerService from '@/services/OwnerService'

export default {
  name: 'customerSearch',
  components: {
    AutoComplete
  },
  created () {
    this.ownerService = OwnerService.getInstance()
  },
  data () {
    return {
    }
  },
  methods: {
    findOwners (regex, input) {
      return new Promise((resolve, reject) => {
        this.ownerService.listOwners()
          .then(data => {
            this.ownerList = data

            const filtered = data.map(item => this.getCustomerName(item)).filter(item => item.match(regex))
            resolve(filtered)
          })
          .catch(err => {
            console.error(err)
            reject(err)
          })
      })
    },
    selectOwner (owner) {
      this.owner = this.ownerList.filter(item => {
        const mapped = this.getCustomerName(item)
        return mapped === owner
      })[0]

      this.$emit('customerSelection', { owner: this.owner })
    },

    getCustomerName (rawCustomer) {
      const firstNameAttribute = rawCustomer.Attributes.filter(i => i.Name === 'given_name')[0] || {}
      const lastNameAttribute = rawCustomer.Attributes.filter(i => i.Name === 'family_name')[0] || {}
      const firstName = firstNameAttribute.Value || 'No first name'
      const lastName = lastNameAttribute.Value || 'No last name'
      return `${firstName} ${lastName}`
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
.section.customer-search {
  width: 100%;
  height: 100%;
  display: block;
}

</style>
