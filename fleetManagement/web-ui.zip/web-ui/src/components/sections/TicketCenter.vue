<template>
  <div class="section ticket-center">
    <div class="panel central lg">
      <h1 class="title">All tickets</h1>
      <div class="list lg">
        <div class="list-header">
          <div class="col col-quarter">Ticket #</div>
          <div class="col col-half">Issue</div>
          <div class="col col-quarter">Time</div>
        </div>
        <div class="list-item lg transparent" v-for="ticket in tickets" v-on:click="gotoVehicle(ticket.vin)">
          <div class="col col-quarter text-muted">{{ ticket.dtc }}</div>
          <div class="col col-half">{{ ticket.description }}</div>
          <div class="col col-quarter text-muted">{{ getTimeAgo(ticket.updated_at) }}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import moment from 'moment'
import DtcService from '@/services/DtcService'

export default {
  name: 'ticketCenter',
  created () {
    this.dtcService = DtcService.getInstance()
  },
  props: ['persona'],
  data () {
    return {
      tickets: []
    }
  },
  mounted () {
    setInterval(() => {
      this.getTickets()
    }, 1000)
  },
  methods: {
    getTickets () {
      this.dtcService.getAllDtcs()
        .then(data => {
          this.tickets = data
          this.$forceUpdate()
        })
        .catch(error => {
          console.error(err)
        })
    },
    getTimeAgo (time) {
      return moment(time).fromNow()
    },
    gotoVehicle (vin) {
      this.$router.push(`/${this.persona}/vehicle-overview/${vin}`)
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
.ticket-center {
}

</style>
